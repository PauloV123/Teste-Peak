﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TelaDeConsulta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_Buscar_Click(object sender, EventArgs e)
        {
            string[] lista = { "João", "Maria", "Ana" };
            int id = int.Parse(txt_ID.Text); // Pega o valor do ID
            if(id == 1)
            {
                //Mostrar Joao
                MessageBox.Show(lista[id - 1]);
            }else if(id == 2)
            {
                //Mostrar Maria
                MessageBox.Show(lista[id - 1]);
            }else if(id == 3)
            {
                MessageBox.Show(lista[id - 1]);
            }
            else
            {
                MessageBox.Show("Número inválido");
            }
        }
    }
}
