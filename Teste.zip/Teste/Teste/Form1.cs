﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teste
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double resultado;
            string resultadoFinal;

            int parcela = int.Parse(txt_Parcela.Text);
            double valor = double.Parse(txt_Valor.Text);

            resultado = ((double)(parcela * valor));
            resultado = resultado + (resultado * 0.05);
            
            resultadoFinal = String.Format("R$ "+ Math.Round(resultado, 4));
            MessageBox.Show(resultadoFinal);
        }
    }
}
